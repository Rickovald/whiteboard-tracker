import "./styles/app.scss"
import SettingBar from "./components/SettingBar";
import Toolbar from "./components/Toolbar";
import Canvas from "./components/Canvas";
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'

const App = () => {
  return (
    <BrowserRouter>
      <div className="app">
        <Routes>
          <Route
            path='/:id'
            element={<Drawer />}
          >
          </Route>
        </Routes>
        <Navigate to={`f${(+new Date()).toString(16)}`} />
      </div>
    </BrowserRouter>
  );
};
const Drawer = () => {
  return (

    <>
      <Toolbar />
      <SettingBar />
      <Canvas />
    </>
  )
}
export default App;
